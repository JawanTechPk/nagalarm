// export const GET_BOOK_DATA = "GET_BOOK_DATA";
// export const SAVE_BOOK_DATA = "SAVE_BOOK_DATA";
// export const GET_ISBN = "GET_ISBN";

export const MODAL_UPDATE = "MODAL_UPDATE";




